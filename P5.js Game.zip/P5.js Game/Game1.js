// JavaScript source code
let x = 100;
let y = 100;
var l = 200;
var m = 200;
var speed = 4;
var speed2 = 2;
var a = 100;
var b = 100;
var clickx = 0;
var clicky = 0;

function setup() {
    createCanvas(400, 400);
    fill(255, 0, 0);
}

function draw() {
    background(220);
    fill(100, 133, 160);
    ellipse(l, m, 50, 50);
    ellipse(a, b, 50, 50);
    fill(255, 0, 0);
    ellipse(x, y, 50, 50);
    fill(190, 90, 111);
    rect(clickx, clicky, 20, 20);
    fill(0);
    rect(300, 0, 80, 50);
    fill(255);
    textSize(30);
    text("Exit", 300, 30)


    l += speed;
    b += speed2;

    if (l >= 400) { l = 0; }
    else if (m >= 400) { m = 0; }

    if (a >= 400) { x = 0; }
    else if (b >= 400) { b = 0; }

    if (x >= 400) { x = 0; }
    else if (y >= 400) { y = 0; }



    if (keyIsDown(LEFT_ARROW)) {
        x -= 5;
    }

    if (keyIsDown(RIGHT_ARROW)) {
        x += 5;
    }

    if (keyIsDown(UP_ARROW)) {
        y -= 5;
    }

    if (keyIsDown(DOWN_ARROW)) {
        y += 5;
    }

    if (x > 300 && y <= 50) {
        text("You Won!", 150, 50);
    }

}

function mouseClicked() {
    clickx = mouseX;
    clicky = mouseY;
}

